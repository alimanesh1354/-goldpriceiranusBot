ربات قیمت طلا و ارز
BOT_TOKEN: توکن BotFather (محرمانه)
CHANNEL: @gold_price_Iran_us
PRICE_API_URL: آدرس API قیمت‌ها
INTERVAL_SECONDS: 3600
API باید JSON با کلیدهای ounce, gold18, usd, eur, usdt برگرداند.
