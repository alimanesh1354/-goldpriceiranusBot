import os, json, time
from datetime import datetime
import requests

BOT_TOKEN = os.environ["BOT_TOKEN"]
CHANNEL = os.getenv("CHANNEL", "@gold_price_Iran_us")
PRICE_API_URL = os.environ["PRICE_API_URL"]
INTERVAL_SECONDS = int(os.getenv("INTERVAL_SECONDS", "3600"))
STATE_FILE = "last_prices.json"

def get_prices():
    r = requests.get(PRICE_API_URL, timeout=20)
    r.raise_for_status()
    d = r.json()
    return {k: float(d[k]) for k in ("ounce","gold18","usd","eur","usdt")}

def load_previous():
    try:
        with open(STATE_FILE, encoding="utf-8") as f: return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError): return {}

def save_previous(p):
    with open(STATE_FILE, "w", encoding="utf-8") as f: json.dump(p, f)

def change(now, old):
    if old is None or old == 0: return "➖"
    x = (now-old)/old*100
    return f"🔵 +{x:.2f}%" if x > 0 else f"🔴 {x:.2f}%" if x < 0 else "➖ 0.00%"

def toman(x): return f"{round(x):,}"

def send(text):
    r = requests.post(f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
                      json={"chat_id": CHANNEL, "text": text}, timeout=20)
    r.raise_for_status()

def publish():
    p, old = get_prices(), load_previous()
    now = datetime.now().strftime("%Y/%m/%d - %H:%M")
    msg = (
        "📊 قیمت طلا و ارز ایران\n"
        f"🕐 آخرین بروزرسانی: {now}\n\n"
        f"🥇 اونس طلا: {p['ounce']:,.2f} دلار\n"
        f"🟡 طلای ۱۸ عیار: {toman(p['gold18'])} تومان\n"
        f"💵 دلار: {toman(p['usd'])} تومان\n"
        f"💶 یورو: {toman(p['eur'])} تومان\n"
        f"₮ تتر: {toman(p['usdt'])} تومان\n\n"
        "📈 تغییر نسبت به ساعت قبل:\n"
        f"اونس طلا: {change(p['ounce'],old.get('ounce'))}\n"
        f"طلای ۱۸ عیار: {change(p['gold18'],old.get('gold18'))}\n"
        f"دلار: {change(p['usd'],old.get('usd'))}\n"
        f"یورو: {change(p['eur'],old.get('eur'))}\n"
        f"تتر: {change(p['usdt'],old.get('usdt'))}"
    )
    send(msg); save_previous(p)

if __name__ == "__main__":
    while True:
        try: publish()
        except Exception as e: print("ERROR:", e, flush=True)
        time.sleep(INTERVAL_SECONDS)
