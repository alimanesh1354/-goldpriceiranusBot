import os, json, time
from datetime import datetime
import requests

BOT_TOKEN = os.environ["BOT_TOKEN"]
CHANNEL = os.getenv("CHANNEL", "@gold_price_Iran_us")
ARZBIN_API_KEY = os.environ["ARZBIN_API_KEY"]
INTERVAL_SECONDS = int(os.getenv("INTERVAL_SECONDS", "3600"))
STATE_FILE = "last_prices.json"

BASE = "https://hub.arzbin.com"
HEADERS = {"Authorization": f"Bearer {ARZBIN_API_KEY}", "Accept": "application/json"}

def get_json(path):
    r = requests.get(BASE + path, headers=HEADERS, timeout=25)
    r.raise_for_status()
    return r.json()

def find_value(obj, codes):
    codes = {c.upper() for c in codes}
    def walk(x):
        if isinstance(x, dict):
            code = str(x.get("code", x.get("symbol", ""))).upper()
            if code in codes:
                for k in ("sell", "price", "value", "last", "close", "toman"):
                    if isinstance(x.get(k), (int, float)):
                        return float(x[k])
            for v in x.values():
                y = walk(v)
                if y is not None: return y
        elif isinstance(x, list):
            for v in x:
                y = walk(v)
                if y is not None: return y
        return None
    return walk(obj)

def get_prices():
    rates = get_json("/api/v1/market/rates")
    gold = get_json("/api/v1/market/gold")
    crypto = get_json("/api/v1/market/crypto")
    p = {
        "usd": find_value(rates, ["USD"]),
        "eur": find_value(rates, ["EUR"]),
        "gold18": find_value(gold, ["GOLD18", "GOLD-18K", "GOLD_18K", "18K", "GOLD18K"]),
        "ounce": find_value(gold, ["XAUUSD", "XAU", "GOLD-OUNCE", "OUNCE"]),
        "usdt": find_value(crypto, ["USDT", "TETHER"]),
    }
    missing = [k for k,v in p.items() if v is None]
    if missing: raise RuntimeError("API field not found: " + ", ".join(missing))
    return p

def load_previous():
    try:
        with open(STATE_FILE, encoding="utf-8") as f: return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError): return {}

def save_previous(p):
    with open(STATE_FILE, "w", encoding="utf-8") as f: json.dump(p, f, ensure_ascii=False)

def change(now, old):
    if old is None or old == 0: return "➖"
    pct = (now-old)/old*100
    if pct > 0: return f"🔵 +{pct:.2f}%"
    if pct < 0: return f"🔴 {pct:.2f}%"
    return "➖ 0.00%"

def toman(x): return f"{round(x):,}"

def send(text):
    r = requests.post(
        f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
        json={"chat_id": CHANNEL, "text": text}, timeout=25)
    r.raise_for_status()

def publish():
    p, old = get_prices(), load_previous()
    now = datetime.now().strftime("%Y/%m/%d - %H:%M")
    msg = (
        "📊 قیمت طلا و ارز ایران\n"
        f"🕐 آخرین بروزرسانی: {now}\n\n"
        f"🥇 اونس طلا: {p['ounce']:,.2f} دلار\n"
        f"🟡 طلای ۱۸ عیار: {toman(p['gold18'])} تومان\n"
        f"💵 دلار: {toman(p['usd'])} تومان\n"
        f"💶 یورو: {toman(p['eur'])} تومان\n"
        f"₮ تتر: {toman(p['usdt'])} تومان\n\n"
        "📈 تغییر نسبت به ساعت قبل:\n"
        f"اونس طلا: {change(p['ounce'],old.get('ounce'))}\n"
        f"طلای ۱۸ عیار: {change(p['gold18'],old.get('gold18'))}\n"
        f"دلار: {change(p['usd'],old.get('usd'))}\n"
        f"یورو: {change(p['eur'],old.get('eur'))}\n"
        f"تتر: {change(p['usdt'],old.get('usdt'))}\n\n"
        "📌 منبع داده: Arzbin\n"
        "⚠️ قیمت‌ها تقریبی/شاخصی هستند و ممکن است با قیمت معامله واقعی تفاوت داشته باشند."
    )
    send(msg)
    save_previous(p)

if __name__ == "__main__":
    while True:
        try: publish()
        except Exception as e: print("ERROR:", repr(e), flush=True)
        time.sleep(INTERVAL_SECONDS)
